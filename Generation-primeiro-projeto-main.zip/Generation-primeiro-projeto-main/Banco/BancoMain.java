package Banco;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BancoMain {
	public static void main(String[] args) {

		int op = 0;
		Scanner scan = new Scanner(System.in);
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		Cliente cliente = null;

		do {

			//------------- MENU PRINCIPAL---------------------
			try {
				System.out.println("\nBem vindo!\nDigite\n(1)Entrar\n(2)Cadastrar");
				op = scan.nextInt();

			} catch (InputMismatchException InputMismatchException) {
				scan.nextLine();
				System.out.println(
						"Alguns dados foram inseridos de maneira incorreta, por favor,verifique se voce esta digitando numeros inteiros!");

			}

			if (op == 2) {
				cliente = new Cliente();
				clientes.add(cliente);
				cliente.setCodigoConta(clientes.indexOf(cliente));
				System.out.println("ANOTE O SEU NUMERO DA CONTA PARA POSTERIORMENTE FAZER O ACESSO!\nNumero da conta: " + cliente.getCodigoConta());

			} else if (op == 1) {
				try {
					cliente = Cliente.validar(clientes);
					cliente.transacao(cliente,clientes);

				} catch (IndexOutOfBoundsException IndexOutOfBoundsException) {
					System.out.println("Numero da conta ou senha invalidos,tente novamente!");
				}
			}

		} while (op != -1);
		scan.close();
		System.out.println("\nSistema finalizado!");

	}
}